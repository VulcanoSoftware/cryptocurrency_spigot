package com.rabbitcompany.utils;

import java.util.HashMap;
import java.util.List;

public class Settings {
	//Crypto currencies
	public static HashMap<String, Crypto> cryptos = new HashMap<>();
	//Crypto mining
	public static HashMap<String, List<Mining>> mining = new HashMap<>();
}